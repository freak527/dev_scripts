* typing:
  - pip install typing
  - https://github.com/python/typing
  - current version: 3.5.2.2
